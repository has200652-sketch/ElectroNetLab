package com.electrolab.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.hypot
import java.util.Locale

private val navy = Color(0xFF102A43)
private val teal = Color(0xFF087E8B)
private val board = Color(0xFFF5F8FA)

data class PartType(val title: String, val short: String, val defaultValue: Double, val unit: String)
data class PlacedPart(val id: Int, val type: PartType, val x: Float, val y: Float, val value: Double)
data class Wire(val from: Int, val to: Int)

private val types = listOf(
    PartType("باتری DC", "BAT", 9.0, "V"),
    PartType("مقاومت", "R", 1000.0, "Ω"),
    PartType("LED", "LED", 2.0, "V"),
    PartType("خازن", "C", 100.0, "µF"),
    PartType("دیود", "D", 0.7, "V"),
    PartType("ترانزیستور NPN", "NPN", 1.0, "قطعه"),
    PartType("آی‌سی 555", "555", 1.0, "IC"),
    PartType("رگولاتور 7805", "7805", 5.0, "V")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ElectroLabProApp() }
    }
}

@Composable
fun ElectroLabProApp() {
    var parts by remember { mutableStateOf(listOf<PlacedPart>()) }
    var wires by remember { mutableStateOf(listOf<Wire>()) }
    var nextId by remember { mutableIntStateOf(1) }
    var selectedId by remember { mutableIntStateOf(-1) }
    var connectMode by remember { mutableStateOf(false) }
    var firstWireEnd by remember { mutableIntStateOf(-1) }
    var running by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("برای افزودن قطعه، از نوار پایین انتخاب کنید.") }
    var showLibrary by remember { mutableStateOf(false) }
    var showValues by remember { mutableStateOf(false) }\n    var showScope by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(primary = teal, secondary = navy, background = board)) {
        Scaffold(
            topBar = {
                Surface(color = navy) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp)) {
                        Text("ElectroLab Pro", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("آزمایشگاه مجازی مدارهای الکترونیکی", color = Color(0xFFD8E7EF), fontSize = 12.sp)
                    }
                }
            },
            bottomBar = {
                Column(Modifier.background(Color.White).padding(8.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        types.forEach { type ->
                            FilledTonalButton(onClick = {
                                parts = parts + PlacedPart(nextId, type, 100f + (parts.size % 2) * 150f,
                                    100f + (parts.size / 2) * 120f, type.defaultValue)
                                selectedId = nextId
                                nextId++
                                running = false
                                message = "${type.title} به صفحه اضافه شد؛ برای جابه‌جایی آن را بکشید."
                            }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                                Text(type.short)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            connectMode = !connectMode
                            firstWireEnd = -1
                            message = if (connectMode) "حالت سیم‌کشی: دو قطعه را یکی پس از دیگری لمس کنید." else "حالت سیم‌کشی خاموش شد."
                        }, colors = ButtonDefaults.buttonColors(containerColor = if (connectMode) Color(0xFFB45309) else teal),
                            modifier = Modifier.weight(1f)) { Text(if (connectMode) "پایان سیم‌کشی" else "سیم‌کشی") }
                        Button(onClick = {
                            running = !running
                            message = if (running) simulate(parts, wires) else "شبیه‌سازی متوقف شد."
                        }, modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFFB91C1C) else Color(0xFF15803D))) {
                            Text(if (running) "توقف مدار" else "▶ اجرای مدار")
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("صفحه شماتیک", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { showLibrary = true }) { Text("کتابخانه قطعات") }
                    TextButton(onClick = { showValues = true }) { Text("تنظیم مقدار") }\n                    TextButton(onClick = { showScope = true }) { Text("اسیلوسکوپ") }
                }
                CircuitCanvas(
                    parts = parts, wires = wires, selectedId = selectedId, connectMode = connectMode,
                    onSelect = { id ->
                        if (connectMode) {
                            if (firstWireEnd == -1) {
                                firstWireEnd = id
                                message = "قطعه اول انتخاب شد؛ قطعه دوم را لمس کنید."
                            } else if (firstWireEnd != id) {
                                wires = wires + Wire(firstWireEnd, id)
                                firstWireEnd = -1
                                message = "اتصال ثبت شد."
                            }
                        } else selectedId = id
                    },
                    onMove = { id, dx, dy ->
                        parts = parts.map { if (it.id == id) it.copy(x = (it.x + dx).coerceIn(55f, 340f), y = (it.y + dy).coerceIn(55f, 750f)) else it }
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
                Surface(color = Color(0xFFE6F0F3)) {
                    Text(message, Modifier.fillMaxWidth().padding(12.dp), color = navy, fontSize = 13.sp)
                }
                if (parts.isEmpty()) {
                    Text("از نوار پایین قطعات را اضافه کنید.", Modifier.align(Alignment.CenterHorizontally).padding(10.dp),
                        color = Color.Gray)
                }
            }
        }

        if (showLibrary) {
            AlertDialog(onDismissRequest = { showLibrary = false }, title = { Text("کتابخانه قطعات") },
                text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                    types.forEach { Text("${it.title} (${it.short}) — مقدار پیش‌فرض: ${it.defaultValue} ${it.unit}", Modifier.padding(vertical = 5.dp)) }
                    Text("برای اطلاعات دقیق پایه‌ها و محدوده کاری، دیتاشیت قطعه واقعی را بررسی کنید.", color = Color.Gray)
                } },
                confirmButton = { TextButton(onClick = { showLibrary = false }) { Text("بستن") } })
        }
        if (showValues) {
            val chosen = parts.firstOrNull { it.id == selectedId }
            var valueText by remember(chosen?.id) { mutableStateOf(chosen?.value?.toString() ?: "") }
            AlertDialog(onDismissRequest = { showValues = false },
                title = { Text("تنظیم مقدار قطعه") },
                text = {
                    if (chosen == null) Text("ابتدا یک قطعه را روی صفحه انتخاب کنید.")
                    else Column {
                        Text("${chosen.type.title} — ${chosen.type.unit}")
                        OutlinedTextField(valueText, { valueText = it }, label = { Text("مقدار") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsed = valueText.toDoubleOrNull()
                        if (chosen != null && parsed != null && parsed > 0) {
                            parts = parts.map { if (it.id == chosen.id) it.copy(value = parsed) else it }
                            message = "مقدار ${chosen.type.title} به‌روزرسانی شد."
                            running = false
                        }
                        showValues = false
                    }) { Text("ذخیره") }
                },
                dismissButton = { TextButton(onClick = { showValues = false }) { Text("انصراف") } })
        }
        if (showScope) {
            ScopeDialog(onClose = { showScope = false })
        }
    }
}

@Composable
fun CircuitCanvas(
    parts: List<PlacedPart>, wires: List<Wire>, selectedId: Int, connectMode: Boolean,
    onSelect: (Int) -> Unit, onMove: (Int, Float, Float) -> Unit, modifier: Modifier = Modifier
) {
    var draggingId by remember { mutableIntStateOf(-1) }
    Box(modifier.background(board)) {
        Canvas(Modifier.fillMaxSize().pointerInput(parts, connectMode) {
            detectTapGestures { tap ->
                val hit = parts.minByOrNull { hypot(it.x - tap.x, it.y - tap.y) }
                if (hit != null && hypot(hit.x - tap.x, hit.y - tap.y) < 75f) onSelect(hit.id)
            }
        }.pointerInput(parts) {
            detectDragGestures(
                onDragStart = { start ->
                    val hit = parts.minByOrNull { hypot(it.x - start.x, it.y - start.y) }
                    draggingId = if (hit != null && hypot(hit.x - start.x, hit.y - start.y) < 75f) hit.id else -1
                },
                onDrag = { change, drag ->
                    change.consume()
                    if (draggingId != -1 && !connectMode) onMove(draggingId, drag.x, drag.y)
                },
                onDragEnd = { draggingId = -1 }
            )
        }) {
            val step = 28f
            var x = 0f
            while (x < size.width) {
                var y = 0f
                while (y < size.height) {
                    drawCircle(Color(0xFFD5E0E5), radius = 1.7f, center = Offset(x, y))
                    y += step
                }
                x += step
            }
            wires.forEach { wire ->
                val a = parts.firstOrNull { it.id == wire.from }
                val b = parts.firstOrNull { it.id == wire.to }
                if (a != null && b != null) {
                    drawLine(Color(0xFF16803C), Offset(a.x, a.y), Offset(b.x, b.y), strokeWidth = 5f)
                }
            }
            parts.forEach { p ->
                val color = if (p.id == selectedId) Color(0xFFFFD166) else Color.White
                drawRoundRect(color, topLeft = Offset(p.x - 48f, p.y - 29f),
                    size = Size(96f, 58f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f),
                    style = Stroke(width = if (p.id == selectedId) 4f else 2f))
                drawCircle(teal, radius = 5f, center = Offset(p.x - 48f, p.y))
                drawCircle(teal, radius = 5f, center = Offset(p.x + 48f, p.y))
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.rgb(16, 42, 67)
                        textSize = 24f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isFakeBoldText = true
                    }
                    drawText(p.type.short, p.x, p.y + 8f, paint)
                    paint.textSize = 15f
                    paint.isFakeBoldText = false
                    drawText("${p.value} ${p.type.unit}", p.x, p.y + 49f, paint)
                }
            }
        }
        if (connectMode) {
            Surface(Modifier.align(Alignment.TopCenter).padding(8.dp), color = Color(0xFFFFF1D6),
                shape = RoundedCornerShape(8.dp)) {
                Text("سیم‌کشی فعال: دو قطعه را لمس کنید", Modifier.padding(8.dp), color = Color(0xFF8A4B08), fontSize = 12.sp)
            }
        }
    }
}


@Composable
fun ScopeDialog(onClose: () -> Unit) {
    var amplitude by remember { mutableStateOf("2.0") }
    var frequency by remember { mutableStateOf("1000") }
    var r1 by remember { mutableStateOf("10000") }
    var r2 by remember { mutableStateOf("10000") }
    var cap by remember { mutableStateOf("0.00001") }

    val amp = amplitude.toFloatOrNull()?.coerceIn(0f, 20f) ?: 2f
    val freq = frequency.toFloatOrNull()?.coerceIn(1f, 100000f) ?: 1000f
    val rr1 = r1.toDoubleOrNull()
    val rr2 = r2.toDoubleOrNull()
    val cc = cap.toDoubleOrNull()
    val timerHz = if (rr1 != null && rr2 != null && cc != null && rr1 > 0 && rr2 > 0 && cc > 0)
        1.44 / ((rr1 + 2 * rr2) * cc) else null

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("اسیلوسکوپ مجازی و محاسبه 555") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("نمایش موج سینوسی نمونه", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(amplitude, { amplitude = it }, modifier = Modifier.weight(1f),
                        label = { Text("دامنه (V)") }, singleLine = true)
                    OutlinedTextField(frequency, { frequency = it }, modifier = Modifier.weight(1f),
                        label = { Text("فرکانس (Hz)") }, singleLine = true)
                }
                Canvas(Modifier.fillMaxWidth().height(150.dp).background(Color(0xFF102A43), RoundedCornerShape(8.dp))) {
                    val mid = size.height / 2f
                    drawLine(Color(0xFF668096), Offset(0f, mid), Offset(size.width, mid), 1f)
                    for (i in 1..9) drawLine(Color(0xFF28485E), Offset(size.width * i / 10f, 0f),
                        Offset(size.width * i / 10f, size.height), 1f)
                    val path = androidx.compose.ui.graphics.Path()
                    for (i in 0..300) {
                        val x = size.width * i / 300f
                        val phase = i / 300f * 2f * Math.PI * (freq / 1000f).coerceIn(0.25f, 4f)
                        val y = mid - (amp / 10f * size.height * 0.42f) * kotlin.math.sin(phase).toFloat()
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, Color(0xFF4ADE80), style = Stroke(width = 3f))
                }
                Text("موج نمایشی است؛ به ورودی واقعی مدار متصل نیست.", color = Color.Gray, fontSize = 12.sp)
                Divider()
                Text("محاسبه تایمر 555 در حالت آستابل", fontWeight = FontWeight.Bold)
                OutlinedTextField(r1, { r1 = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("R1 (Ω)") }, singleLine = true)
                OutlinedTextField(r2, { r2 = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("R2 (Ω)") }, singleLine = true)
                OutlinedTextField(cap, { cap = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("C (F) — مثلاً 0.00001") }, singleLine = true)
                Text(if (timerHz != null && timerHz.isFinite())
                    "فرکانس تقریبی: ${fmt(timerHz)} Hz\\nدوره تناوب: ${fmt(1.0 / timerHz)} s"
                    else "مقادیر R1، R2 و C باید مثبت باشند.")
                Text("فرمول تقریبی: f ≈ 1.44 / ((R1 + 2R2) × C)", color = Color.Gray, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("بستن") } }
    )
}

private fun simulate(parts: List<PlacedPart>, wires: List<Wire>): String {
    val battery = parts.firstOrNull { it.type.short == "BAT" }
        ?: return "خطا: منبع تغذیه BAT روی صفحه وجود ندارد."
    val resistor = parts.firstOrNull { it.type.short == "R" }
        ?: return "خطا: مقاومت در مدار پیدا نشد."
    val led = parts.firstOrNull { it.type.short == "LED" }
        ?: return "مدار آزمایشی آماده نیست؛ یک LED هم اضافه کنید."
    val path = wires.any { (it.from == battery.id && it.to == resistor.id) || (it.to == battery.id && it.from == resistor.id) } &&
        wires.any { (it.from == resistor.id && it.to == led.id) || (it.to == resistor.id && it.from == led.id) }
    if (!path) return "مدار باز است: برای مدل آزمایشی، باتری، مقاومت و LED را با دو اتصال به هم وصل کنید."
    val current = (battery.value - led.value) / resistor.value * 1000.0
    if (current <= 0) return "LED روشن نمی‌شود: ولتاژ منبع باید از افت ولتاژ LED بیشتر باشد."
    val power = current * current / 1000000.0 * resistor.value
    return "شبیه‌سازی آموزشی انجام شد: مسیر BAT → R → LED شناسایی شد.\nجریان تقریبی: ${fmt(current)} mA\nتوان مقاومت: ${fmt(power)} W\nاین مدل ساده است و رفتار گذرا یا همه توپولوژی‌های مدار را حل نمی‌کند."
}

private fun fmt(x: Double) = String.format(Locale.US, "%.3f", x)
